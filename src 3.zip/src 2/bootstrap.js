
$('#toggler').on('click', function () {
  $('.sidebar').toggleClass('.navbar navbar-noshow');
  $("#toggler").toggleClass('flip');
});

$('li > button').on('click', function() {
  $(this).find('i').toggleClass('fa-plus fa-minus');
});

// $(document).ready(function () {
//     $("#fold").click(function () {
//         $("#fold_p").fadeOut(function () {
//             $("#fold_p").text(($("#fold_p").text() == 'Fold it') ? 'Expand it' : 'Fold it').fadeIn();
//         })
//     })
// });


// var timer = document.getElementsByClassName('#timer-time');
// var toggleBtn = document.getElementsById('start');
// var resetBtn = document.getElementById('reset');
//
// var t = timer[0];
// console.log(t);

var timer = document.getElementsByClassName('timer-time');
var toggleBtn = document.getElementsByClassName('timer-button-start');
var resetBtn = document.getElementsByClassName('timer-button-reset');


var timer1 = timer[0];
var toggleBtn1 = toggleBtn[0];
var resetBtn1 = resetBtn[0];

// var timer = document.getElementById('amrap-timer-time');
// var toggleBtn = document.getElementById('start');
// var resetBtn = document.getElementById('reset');

function timeFormatter(time) {

      minutes = parseInt(time / 60, 10)
      seconds = parseInt(time % 60, 10);

      minutes = minutes < 10 ? "0" + minutes : minutes;
      seconds = seconds < 10 ? "0" + seconds : seconds;

  return minutes + ':' + seconds;
}


var amrap_t = new Amrap(timer1);

function start() {
  amrap_t.start();
}

function stop() {
  amrap_t.stop();
}

toggleBtn1.addEventListener('click', function() {
  $(this).find('i').toggleClass('fa-pause fa-play');
  amrap_t.isOn ? stop() : start();
});

resetBtn1.addEventListener('click', function() {
  amrap_t.reset();
});



function Amrap(elem) {
  var time = 5;
  var interval;
  var ding;
  var timer1 = timer[0];
  timer1.innerHTML = timeFormatter(time);

  function update() {
    if (this.isOn) {
      time--;
     if (time < 0){
      clearInterval(interval);
      this.reset();
    }
  }
    elem.textContent = timeFormatter(time);
  }

  this.start = function() {
    interval = setInterval(update.bind(this), 1000);

    this.isOn = true;
  };

  this.stop = function() {
    clearInterval(interval);
    interval = null;
    this.isOn = false;
  };

  this.reset = function() {
    time = 5;
    update();
  };

  this.isOn = false;
}

//
// $(timer1).clone().prependTo($('.timer-time-0'));
// $(toggleBtn1).clone().prependTo($('.timer-button-start-0'));
// $(resetBtn1).clone().prependTo($('.timer-button-reset-0'));

// //
// $('#amrap-timer-time').clone(true).appendTo('#amrap-timer-time-0');
// $('#reset').clone(true).appendTo('#reset-0');
// $('#reset').clone(true).appendTo('#reset-0');
//
// var h0 = $('h4')[0],
//     start0 = document.getElementById('start0'),
//     stop0 = document.getElementById('stop0'),
//     clear0 = document.getElementById('clear0'),
//     seconds = $('.slide-catnum')[0],
// 	  seconds = $(seconds).html(),
//     t;
//
// function subtract() {
//     seconds--;
//     if (seconds < 0) {
//           h0.textContent = ":" + $('.slide-catnum').html();
//           seconds = $('.slide-catnum').html()
//           clearTimeout(t);
//           if ($('#stop0').is(":hidden")) {
//             console.log('true');
//           }else {
//             $('#stop0').toggle();
//             $('#start0').toggle();
//           }
//     } else {
//       h0.textContent = ":" + (seconds > 9 ? seconds : "0" + seconds);
//     timer();
//     }
// }
//
// function timer() {
//     t = setTimeout(subtract, 1000);
// }
