
$('#toggler').on('click', function () {
  $('.sidebar').toggleClass('.navbar navbar-noshow');
  $("#toggler").toggleClass('flip');
});

$('li > button').on('click', function() {
  $(this).find('i').toggleClass('fa-plus fa-minus');
});




// var timer = document.getElementsByClassName('#timer-time');
// var toggleBtn = document.getElementsById('start');
// var resetBtn = document.getElementById('reset');
//
// var t = timer[0];
// console.log(t);

var timer = document.getElementsByClassName('timer-time');
var toggleBtn = document.getElementsByClassName('timer-button-start');
var resetBtn = document.getElementsByClassName('timer-button-reset');


var timer1 = timer[0];
var toggleBtn1 = toggleBtn[0];
var resetBtn1 = resetBtn[0];

// var timer = document.getElementById('amrap-timer-time');
// var toggleBtn = document.getElementById('start');
// var resetBtn = document.getElementById('reset');

function timeFormatter(time) {

      minutes = parseInt(time / 60, 10)
      seconds = parseInt(time % 60, 10);

      minutes = minutes < 10 ? "0" + minutes : minutes;
      seconds = seconds < 10 ? "0" + seconds : seconds;

  return minutes + ':' + seconds;
}


var amrap_t = new Amrap(timer1);

function start() {
  amrap_t.start();
}

function stop() {
  amrap_t.stop();
}

toggleBtn1.addEventListener('click', function() {
  $(this).find('i').toggleClass('fa-pause fa-play');
  amrap_t.isOn ? stop() : start();
});

resetBtn1.addEventListener('click', function() {
  amrap_t.reset();
});



function Amrap(elem) {
  var time = 600;
  var interval;
  var ding;
  var timer1 = timer[0];
  timer1.innerHTML = timeFormatter(time);

  function update() {
    if (this.isOn) {
      time--;
     if (time < 0){
      clearInterval(interval);
      this.reset();
    }
  }
    elem.textContent = timeFormatter(time);
  }

  this.start = function() {
    interval = setInterval(update.bind(this), 1000);

    this.isOn = true;
  };

  this.stop = function() {
    clearInterval(interval);
    interval = null;
    this.isOn = false;
  };

  this.reset = function() {
    time = 600;
    update();
  };

  this.isOn = false;
}


var h0 = $('.timer-time'),
    start0 = document.getElementById('start0'),
    stop0 = document.getElementById('stop0'),
    clear0 = document.getElementById('clear0'),
	  seconds = $(h0).html(),
    t;
$('.start0').on('click', function() {
  $(this).toggleClass('stop0');
})
function subtract() {
    seconds--;
    if (seconds < 0) {
          h0.textContent = ":" + $('h0').html();
          seconds = $(h0).html()
          clearTimeout(t);
          if ($('#stop0').is(":hidden")) {
            console.log('true');
          }else {
            $('#stop0').toggle();
            $('#start0').toggle();
          }
    } else {
      h0.textContent = ":" + (seconds > 9 ? seconds : "0" + seconds);
    timer();
    }
}

function timer() {
    t = setTimeout(subtract, 1000);
}
